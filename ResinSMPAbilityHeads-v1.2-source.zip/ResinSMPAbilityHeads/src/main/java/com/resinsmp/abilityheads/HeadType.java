package com.resinsmp.abilityheads;

import java.util.Arrays;
import java.util.Locale;
import java.util.Optional;

/** The complete set of 35 ResinSMP heads. */
public enum HeadType {
    ZOMBIE("Zombie", "COMMON", "Undead Strength", "Strength I while worn; Undead Surge on use", "ZOMBIE_HEAD"),
    SKELETON("Skeleton", "COMMON", "Deadeye", "Projectile focus and a short precision boost", "SKELETON_SKULL"),
    CREEPER("Creeper", "COMMON", "Blast Jump", "Launch yourself upward without block damage", "CREEPER_HEAD"),
    SPIDER("Spider", "COMMON", "Wall Crawler", "Jump boost while worn; a sharp wall-hop on use", "PLAYER_HEAD"),
    CHICKEN("Chicken", "COMMON", "Feather Flight", "Slow Falling while worn and a feather lift on use", "PLAYER_HEAD"),
    PIG("Pig", "COMMON", "Pig Rush", "A quick burst of speed", "PLAYER_HEAD"),
    COW("Cow", "COMMON", "Nature's Gift", "Regeneration while worn; a stronger healing pulse on use", "PLAYER_HEAD"),
    SHEEP("Sheep", "COMMON", "Soft Landing", "Greatly reduced fall damage", "PLAYER_HEAD"),
    BAT("Bat", "COMMON", "Night Vision X", "Night Vision X while worn; a brief sonic pulse on use", "PLAYER_HEAD"),
    TURTLE("Turtle", "COMMON", "Shell Guard", "Resistance while worn; a defensive shell burst", "PLAYER_HEAD"),

    ENDERMAN("Enderman", "RARE", "Shadow Step", "Teleport a short, safe distance forward", "PLAYER_HEAD"),
    BLAZE("Blaze", "RARE", "Inferno Guard", "Fire resistance and a fiery projectile", "PLAYER_HEAD"),
    STRAY("Stray", "RARE", "Frost Trap", "Chill nearby hostile targets", "PLAYER_HEAD"),
    WOLF("Wolf", "RARE", "Predator Instinct", "Speed II while worn; rally nearby allies", "PLAYER_HEAD"),
    FOX("Fox", "RARE", "Quick Escape", "A fast backward dash", "PLAYER_HEAD"),
    BEE("Bee", "RARE", "Honey Shield", "Absorption and resistance for a short time", "PLAYER_HEAD"),
    DOLPHIN("Dolphin", "RARE", "Ocean Spirit", "Water Breathing and swim speed while worn; water surge", "PLAYER_HEAD"),
    GUARDIAN("Guardian", "RARE", "Aqua Pulse", "A pulse pushes nearby hostile targets away", "PLAYER_HEAD"),
    GOAT("Goat", "RARE", "Ram Attack", "A short forward charge", "PLAYER_HEAD"),
    HOGLIN("Hoglin", "RARE", "Brutal Charge", "Knockback resistance and a forward rush", "PLAYER_HEAD"),

    WITHER_SKELETON("Wither Skeleton", "EPIC", "Wither Strike", "Empower your next melee hits with a brief wither effect", "WITHER_SKELETON_SKULL"),
    GHAST("Ghast", "EPIC", "Ghost Dash", "A short invisible speed burst", "PLAYER_HEAD"),
    SHULKER("Shulker", "EPIC", "Gravity Lock", "Lift nearby hostile targets briefly", "PLAYER_HEAD"),
    EVOKER("Evoker", "EPIC", "Mystic Ward", "A powerful temporary protective ward", "PLAYER_HEAD"),
    PILLAGER("Pillager", "EPIC", "Marksman's Focus", "Temporarily empower projectile hits", "PLAYER_HEAD"),
    RAVAGER("Ravager", "EPIC", "Ravager Rush", "A strong forward charge with a shockwave", "PLAYER_HEAD"),
    PHANTOM("Phantom", "EPIC", "Phantom Drift", "Slow Falling and aerial mobility", "PLAYER_HEAD"),
    SLIME("Slime", "EPIC", "Size Shift", "Sneak + right-click to grow; sneak + left-click to shrink", "PLAYER_HEAD"),

    ENDER_DRAGON("Ender Dragon", "LEGENDARY", "Dragon's Wrath", "A dramatic shockwave around you", "DRAGON_HEAD"),
    WITHER("Wither", "LEGENDARY", "Wither Storm", "A dark aura weakens nearby hostile targets", "PLAYER_HEAD"),
    IRON_GOLEM("Iron Golem", "LEGENDARY", "Titan's Resolve", "Resistance and knockback resistance", "PLAYER_HEAD"),
    WARDEN("Warden", "LEGENDARY", "Sonic Roar", "A powerful sonic shockwave", "PLAYER_HEAD"),
    ELDER_GUARDIAN("Elder Guardian", "LEGENDARY", "Ancient Curse", "A deep-sea pulse slows nearby hostile targets", "PLAYER_HEAD"),
    PIGLIN_BRUTE("Piglin Brute", "LEGENDARY", "Berserker Mode", "A short high-power strength burst", "PIGLIN_HEAD"),
    ALLAY("Allay", "LEGENDARY", "Soulbound Recall", "Sneak + right-click marks a safe point; right-click recalls", "PLAYER_HEAD");

    private final String displayName;
    private final String rarity;
    private final String abilityName;
    private final String description;
    private final String materialName;

    HeadType(String displayName, String rarity, String abilityName, String description, String materialName) {
        this.displayName = displayName;
        this.rarity = rarity;
        this.abilityName = abilityName;
        this.description = description;
        this.materialName = materialName;
    }

    public String id() { return name().toLowerCase(Locale.ROOT); }
    public String displayName() { return displayName; }
    public String rarity() { return rarity; }
    public String abilityName() { return abilityName; }
    public String description() { return description; }
    public String materialName() { return materialName; }

    public static Optional<HeadType> byId(String id) {
        if (id == null) return Optional.empty();
        return Arrays.stream(values()).filter(h -> h.id().equalsIgnoreCase(id)).findFirst();
    }
}
