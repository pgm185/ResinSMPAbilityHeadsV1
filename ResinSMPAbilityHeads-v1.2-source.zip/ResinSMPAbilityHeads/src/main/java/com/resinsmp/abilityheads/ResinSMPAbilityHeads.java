package com.resinsmp.abilityheads;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.Locale;

/** Main plugin entry point and configuration service. */
public final class ResinSMPAbilityHeads extends JavaPlugin {
    private HeadItems headItems;
    private AbilityListener abilityListener;
    private YamlConfiguration abilities;
    private YamlConfiguration drops;
    private YamlConfiguration messages;
    private YamlConfiguration textures;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveBundledIfMissing("abilities.yml");
        saveBundledIfMissing("drops.yml");
        saveBundledIfMissing("messages.yml");
        saveBundledIfMissing("textures.yml");
        reloadAllFiles();

        headItems = new HeadItems(this);
        abilityListener = new AbilityListener(this);
        Bukkit.getPluginManager().registerEvents(abilityListener, this);

        ResinCommand commandHandler = new ResinCommand(this);
        registerCommand("giveallheads", commandHandler);
        registerCommand("resinheads", commandHandler);

        // Passive effects refresh on a short interval and expire naturally after unequipping.
        Bukkit.getScheduler().runTaskTimer(this, abilityListener::tickPassives, 20L, 20L);
        getLogger().info("ResinSMPAbilityHeads enabled with " + HeadType.values().length + " custom heads.");
    }

    @Override
    public void onDisable() {
        if (abilityListener != null) abilityListener.restoreTrackedPlayerState();
        getLogger().info("ResinSMPAbilityHeads disabled.");
    }

    private void registerCommand(String name, ResinCommand handler) {
        var command = getCommand(name);
        if (command == null) {
            getLogger().severe("Command '" + name + "' is missing from plugin.yml.");
            return;
        }
        command.setExecutor(handler);
        command.setTabCompleter(handler);
    }

    private void saveBundledIfMissing(String name) {
        File file = new File(getDataFolder(), name);
        if (!file.exists()) saveResource(name, false);
    }

    public void reloadAllFiles() {
        reloadConfig();
        abilities = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "abilities.yml"));
        drops = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "drops.yml"));
        messages = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "messages.yml"));
        textures = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "textures.yml"));
    }

    public HeadItems headItems() {
        return headItems;
    }

    /** Returns the configured Minecraft profile used to skin a player-head item. */
    public String textureProfile(HeadType head) {
        if (textures == null) return null;
        String profile = textures.getString("heads." + head.id() + ".profile");
        return profile == null || profile.isBlank() ? null : profile.trim();
    }

    public boolean abilityEnabled(HeadType head) {
        return abilities == null || abilities.getBoolean("heads." + head.id() + ".enabled", true);
    }

    public boolean passiveEnabled(HeadType head) {
        return abilities == null || abilities.getBoolean("heads." + head.id() + ".passive-enabled", true);
    }

    public long cooldownMillis(HeadType head) {
        long seconds = abilities == null ? defaultCooldownSeconds(head)
                : abilities.getLong("heads." + head.id() + ".cooldown", defaultCooldownSeconds(head));
        return Math.max(1L, Math.min(3600L, seconds)) * 1000L;
    }

    public double dropChance(EntityType entityType) {
        HeadType head = HeadType.byId(entityType.name().toLowerCase(Locale.ROOT)).orElse(null);
        if (head == null || drops == null) return 0.0;
        String path = "heads." + head.id();
        if (!drops.getBoolean(path + ".enabled", true)) return 0.0;
        double chance = drops.getDouble(path + ".chance", defaultDropChance(head));
        return Math.max(0.0, Math.min(100.0, chance));
    }

    public String message(String key, String... replacements) {
        String fallback = defaultMessage(key);
        String template = messages == null ? fallback : messages.getString("messages." + key, fallback);
        if (replacements != null) {
            for (int i = 0; i + 1 < replacements.length; i += 2) {
                template = template.replace("%" + replacements[i] + "%", replacements[i + 1]);
            }
        }
        return ChatColor.translateAlternateColorCodes('&', template);
    }

    private int defaultCooldownSeconds(HeadType head) {
        return switch (head) {
            case ZOMBIE -> 25; case SKELETON -> 30; case CREEPER -> 20; case SPIDER -> 25;
            case CHICKEN -> 20; case PIG -> 25; case COW -> 35; case SHEEP -> 25; case BAT -> 35; case TURTLE -> 35;
            case ENDERMAN -> 15; case BLAZE -> 20; case STRAY -> 25; case WOLF -> 25; case FOX -> 20;
            case BEE -> 30; case DOLPHIN -> 30; case GUARDIAN -> 25; case GOAT -> 20; case HOGLIN -> 30;
            case WITHER_SKELETON -> 15; case GHAST -> 35; case SHULKER -> 30; case EVOKER -> 40;
            case PILLAGER -> 30; case RAVAGER -> 30; case PHANTOM -> 25; case SLIME -> 3;
            case ENDER_DRAGON -> 90; case WITHER -> 60; case IRON_GOLEM -> 45; case WARDEN -> 60;
            case ELDER_GUARDIAN -> 45; case PIGLIN_BRUTE -> 45; case ALLAY -> 90;
        };
    }

    private double defaultDropChance(HeadType head) {
        return switch (head) {
            case ZOMBIE, SKELETON, CHICKEN, PIG, SHEEP -> 95;
            case CREEPER, SPIDER, COW -> 90;
            case BAT, ENDER_DRAGON, WITHER, IRON_GOLEM, WARDEN, ELDER_GUARDIAN, PIGLIN_BRUTE -> 100;
            case TURTLE -> 85;
            case ENDERMAN, BLAZE, FOX -> 60;
            case STRAY, GUARDIAN -> 55;
            case WOLF, BEE -> 65;
            case DOLPHIN -> 70;
            case GOAT -> 60;
            case HOGLIN -> 50;
            case WITHER_SKELETON, GHAST, SHULKER, EVOKER, PILLAGER, RAVAGER, PHANTOM, SLIME -> 40;
            case ALLAY -> 98;
        };
    }

    private String defaultMessage(String key) {
        return switch (key) {
            case "no-permission" -> "&cYou do not have permission to use this command.";
            case "player-not-found" -> "&cThat player is not online.";
            case "usage" -> "&cUsage: /giveallheads <player>";
            case "reloaded" -> "&aAll ResinSMPAbilityHeads configuration files reloaded.";
            case "unknown-head" -> "&cUnknown head ID. Use /resinheads list.";
            case "given-one" -> "&aGave %head% Head to %player%.";
            case "given-all" -> "&aGave all 35 heads to %player%.";
            case "full-inventory" -> "&eYour inventory was full. Extra heads were dropped nearby.";
            case "disabled" -> "&cThat head's ability is disabled in abilities.yml.";
            case "scale-not-supported" -> "&cThis Paper build does not expose player scaling.";
            case "slime-grown" -> "&aSlime size increased.";
            case "slime-shrunk" -> "&aSlime size decreased.";
            case "allay-marked" -> "&bSoulbound point marked. Right-click to recall.";
            case "allay-no-point" -> "&cNo safe Soulbound point is marked yet.";
            case "allay-recalled" -> "&aSoulbound Recall successful!";
            case "ability-used" -> "&b%ability% activated!";
            case "cooldown" -> "&cAbility ready in %seconds%s.";
            default -> "&7" + key;
        };
    }
}
