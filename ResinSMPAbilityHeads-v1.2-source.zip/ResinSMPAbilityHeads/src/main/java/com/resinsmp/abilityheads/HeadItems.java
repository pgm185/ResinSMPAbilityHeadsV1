package com.resinsmp.abilityheads;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class HeadItems {
    private final ResinSMPAbilityHeads plugin;
    private final NamespacedKey headIdKey;

    public HeadItems(ResinSMPAbilityHeads plugin) {
        this.plugin = plugin;
        this.headIdKey = new NamespacedKey(plugin, "resin_head_id");
    }

    public ItemStack create(HeadType type) {
        Material material = Material.matchMaterial(type.materialName());
        if (material == null || !material.isItem()) material = Material.PLAYER_HEAD;
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;

        // Paper profile names are resolved by Minecraft against Mojang's profile services.
        // Keeping the profile name (rather than downloading textures on the server thread)
        // avoids blocking item creation and lets the client cache the official skin texture.
        String textureProfile = plugin.textureProfile(type);
        if (material == Material.PLAYER_HEAD && textureProfile != null && meta instanceof SkullMeta skullMeta) {
            skullMeta.setPlayerProfile(Bukkit.createProfile(textureProfile));
        }

        meta.setDisplayName(color(rarityColor(type) + "✦ " + type.displayName() + " Head"));
        List<String> lore = new ArrayList<>();
        lore.add(color("&8ResinSMP Ability Head"));
        lore.add(color(rarityColor(type) + "Rarity: " + type.rarity()));
        lore.add(color("&7Ability: &f" + type.abilityName()));
        lore.add(color("&7" + type.description()));
        lore.add(color("&8Wear in helmet slot to activate"));
        lore.add(color("&bRight-click: use ability"));
        if (type == HeadType.SLIME) {
            lore.add(color("&bSneak + Right-click: grow"));
            lore.add(color("&bSneak + Left-click: shrink"));
        }
        if (type == HeadType.ALLAY) lore.add(color("&bSneak + Right-click: mark / Right-click: recall"));
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(headIdKey, PersistentDataType.STRING, type.id());
        stack.setItemMeta(meta);
        return stack;
    }

    public HeadType identify(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) return null;
        String id = stack.getItemMeta().getPersistentDataContainer().get(headIdKey, PersistentDataType.STRING);
        return HeadType.byId(id).orElse(null);
    }

    private String rarityColor(HeadType type) {
        return switch (type.rarity()) {
            case "RARE" -> "&9";
            case "EPIC" -> "&5";
            case "LEGENDARY" -> "&6";
            default -> "&a";
        };
    }

    public static String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }
}
