plugins {
    java
}

group = "com.resinsmp"
version = "1.2.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/") {
        name = "papermc"
    }
}

dependencies {
    // Paper API is supplied by the server; it is not bundled into the plugin JAR.
    compileOnly("io.papermc.paper:paper-api:26.2.build.135-stable")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(25)
}

tasks.jar {
    archiveBaseName.set("ResinSMPAbilityHeads")
    archiveVersion.set(project.version.toString())
}
