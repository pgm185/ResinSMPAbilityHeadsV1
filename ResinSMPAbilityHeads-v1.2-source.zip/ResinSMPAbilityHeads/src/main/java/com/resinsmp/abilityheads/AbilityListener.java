package com.resinsmp.abilityheads;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SmallFireball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.block.BlockState;
import org.bukkit.block.TileState;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class AbilityListener implements Listener {
    private final ResinSMPAbilityHeads plugin;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private final Map<UUID, Long> witherStrikeUntil = new HashMap<>();
    private final Map<UUID, Long> marksmanUntil = new HashMap<>();
    private final Map<UUID, Location> allayAnchors = new HashMap<>();
    private final Map<UUID, Map<PotionEffectType, Integer>> appliedPassives = new HashMap<>();
    private final Map<UUID, Double> originalScales = new HashMap<>();
    private final NamespacedKey spawnerOriginKey;
    private final NamespacedKey placedHeadIdKey;

    public AbilityListener(ResinSMPAbilityHeads plugin) {
        this.plugin = plugin;
        this.spawnerOriginKey = new NamespacedKey(plugin, "spawner_or_egg_origin");
        this.placedHeadIdKey = new NamespacedKey(plugin, "resin_placed_head_id");
    }


    // Preserve the custom identity when a head is placed as a block.
    @EventHandler
    public void onHeadPlace(BlockPlaceEvent event) {
        HeadType type = plugin.headItems().identify(event.getItemInHand());
        if (type == null) return;
        BlockState state = event.getBlockPlaced().getState();
        if (state instanceof TileState tile) {
            tile.getPersistentDataContainer().set(placedHeadIdKey, PersistentDataType.STRING, type.id());
            tile.update(true, false);
        }
    }

    // Replace the vanilla skull drop with the original custom item, preserving its name, lore, ID and skin.
    @EventHandler
    public void onHeadBreak(BlockBreakEvent event) {
        BlockState state = event.getBlock().getState();
        if (!(state instanceof TileState tile)) return;
        String id = tile.getPersistentDataContainer().get(placedHeadIdKey, PersistentDataType.STRING);
        HeadType type = HeadType.byId(id).orElse(null);
        if (type == null) return;
        event.setDropItems(false);
        event.setExpToDrop(0);
        ItemStack customHead = plugin.headItems().create(type);
        event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation().add(0.5, 0.5, 0.5), customHead);
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        boolean wasSpawnerSpawned = entity.getPersistentDataContainer().has(spawnerOriginKey, PersistentDataType.BYTE);
        if (plugin.getConfig().getBoolean("settings.block-spawner-drops", true) && wasSpawnerSpawned) return;
        if (plugin.getConfig().getBoolean("settings.require-player-kill", true) && entity.getKiller() == null) return;
        double chance = plugin.dropChance(entity.getType());
        if (chance <= 0.0) return;
        if (Math.random() * 100.0 >= chance) return;
        HeadType head = HeadType.byId(entity.getType().name().toLowerCase()).orElse(null);
        if (head != null) event.getDrops().add(plugin.headItems().create(head));
    }

    @EventHandler
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER
                || event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG
                || event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.DISPENSE_EGG
                || event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.TRIAL_SPAWNER
                || event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.OMINOUS_ITEM_SPAWNER) {
            event.getEntity().getPersistentDataContainer().set(spawnerOriginKey, PersistentDataType.BYTE, (byte) 1);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Double original = originalScales.remove(player.getUniqueId());
        if (original != null && plugin.getConfig().getBoolean("settings.reset-slime-scale-on-unequip", true)) setScale(player, original);
        Map<PotionEffectType, Integer> applied = appliedPassives.remove(player.getUniqueId());
        if (applied != null) {
            for (Map.Entry<PotionEffectType, Integer> entry : applied.entrySet()) {
                PotionEffect current = player.getPotionEffect(entry.getKey());
                if (current != null && current.getAmplifier() == entry.getValue() && current.getDuration() <= 50) player.removePotionEffect(entry.getKey());
            }
        }
        cooldowns.remove(player.getUniqueId());
        marksmanUntil.remove(player.getUniqueId());
        witherStrikeUntil.remove(player.getUniqueId());
        allayAnchors.remove(player.getUniqueId());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        // v1.2: support air/block clicks, including mobile/controller interaction mappings.
        boolean rightClick = action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK;
        boolean leftClick = action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK;
        if (!rightClick && !leftClick) return;
        if (event.getItem() != null && !event.getItem().getType().isAir()) return;

        Player player = event.getPlayer();
        HeadType head = plugin.headItems().identify(player.getInventory().getHelmet());
        if (head == null) return;

        if (head == HeadType.SLIME) {
            if (player.isSneaking() && (rightClick || leftClick)) {
                event.setCancelled(true);
                if (!ready(player, head)) return;
                if (!plugin.abilityEnabled(head)) {
                    player.sendMessage(plugin.message("disabled"));
                    return;
                }
                double min = plugin.getConfig().getDouble("settings.slime-scale-min", 0.60);
                double max = plugin.getConfig().getDouble("settings.slime-scale-max", 1.60);
                double delta = 0.20;
                double current = getScale(player);
                if (Double.isNaN(current)) {
                    player.sendMessage(plugin.message("scale-not-supported"));
                    return;
                }
                rememberOriginalScale(player, current);
                double next = rightClick ? Math.min(max, current + delta) : Math.max(min, current - delta);
                if (setScale(player, next)) {
                    startCooldown(player, head);
                    player.sendMessage(plugin.message(rightClick ? "slime-grown" : "slime-shrunk"));
                    player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().add(0, 1, 0), 18, 0.35, 0.45, 0.35, 0.05);
                } else player.sendMessage(plugin.message("scale-not-supported"));
            }
            return;
        }

        // Right-click, sneak+right-click and sneak+left-click all activate the worn head's active ability.
        // Allay sneak+right-click remains its mark-point special action.
        if (!rightClick && !(leftClick && player.isSneaking())) return;
        if (action == Action.RIGHT_CLICK_BLOCK || action == Action.LEFT_CLICK_BLOCK) event.setCancelled(true);
        if (!plugin.abilityEnabled(head)) {
            player.sendMessage(plugin.message("disabled"));
            return;
        }
        if (head == HeadType.ALLAY && player.isSneaking()) {
            allayAnchors.put(player.getUniqueId(), player.getLocation().clone());
            player.sendMessage(plugin.message("allay-marked"));
            player.getWorld().spawnParticle(Particle.END_ROD, player.getLocation().add(0, 1, 0), 24, 0.4, 0.5, 0.4, 0.03);
            return;
        }
        if (!ready(player, head)) return;
        if (activate(player, head)) {
            startCooldown(player, head);
            player.sendMessage(plugin.message("ability-used").replace("%ability%", head.abilityName()));
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        HeadType worn = plugin.headItems().identify(player.getInventory().getHelmet());
        if (worn == null || !plugin.passiveEnabled(worn)) return;
        if (worn == HeadType.SHEEP && event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            event.setDamage(event.getDamage() * 0.20);
        }
        if (worn == HeadType.CHICKEN && event.getCause() == EntityDamageEvent.DamageCause.FALL) event.setDamage(event.getDamage() * 0.50);
        if (worn == HeadType.BEE && event.getCause() == EntityDamageEvent.DamageCause.FALL) event.setDamage(event.getDamage() * 0.70);
        if (worn == HeadType.CREEPER && (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                || event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION)) event.setDamage(event.getDamage() * 0.70);
        if (worn == HeadType.TURTLE || worn == HeadType.SHULKER || worn == HeadType.RAVAGER
                || worn == HeadType.WITHER || worn == HeadType.WARDEN || worn == HeadType.IRON_GOLEM) {
            event.setDamage(event.getDamage() * 0.85);
        }
    }

    @EventHandler
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        Player attacker = null;
        boolean projectileHit = false;
        if (event.getDamager() instanceof Player player) attacker = player;
        else if (event.getDamager() instanceof Projectile projectile && projectile.getShooter() instanceof Player player) {
            attacker = player;
            projectileHit = true;
        }
        if (attacker == null) return;

        HeadType worn = plugin.headItems().identify(attacker.getInventory().getHelmet());
        long now = System.currentTimeMillis();
        boolean passiveActive = worn != null && plugin.passiveEnabled(worn);
        if (passiveActive && projectileHit && worn == HeadType.SKELETON) event.setDamage(event.getDamage() * 1.15);
        if (passiveActive && projectileHit && worn == HeadType.PILLAGER) event.setDamage(event.getDamage() * 1.10);
        if (passiveActive && !projectileHit && worn == HeadType.WITHER_SKELETON) event.setDamage(event.getDamage() * 1.10);
        if (passiveActive && !projectileHit && worn == HeadType.PIGLIN_BRUTE) event.setDamage(event.getDamage() * 1.10);
        if (projectileHit && marksmanUntil.getOrDefault(attacker.getUniqueId(), 0L) > now) event.setDamage(event.getDamage() * 1.35);
        if (!projectileHit && worn == HeadType.WITHER_SKELETON && witherStrikeUntil.getOrDefault(attacker.getUniqueId(), 0L) > now
                && event.getEntity() instanceof LivingEntity target) {
            target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0, true, true, true), true);
        }
    }

    public void tickPassives() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            HeadType worn = plugin.headItems().identify(player.getInventory().getHelmet());
            Map<PotionEffectType, Integer> desired = new HashMap<>();
            if (worn != null && plugin.passiveEnabled(worn)) {
                switch (worn) {
                    case ZOMBIE -> desired.put(PotionEffectType.STRENGTH, 0);
                    case SPIDER -> desired.put(PotionEffectType.JUMP_BOOST, 1);
                    case CHICKEN -> desired.put(PotionEffectType.SLOW_FALLING, 0);
                    case PIG -> desired.put(PotionEffectType.SPEED, 0);
                    case COW -> desired.put(PotionEffectType.REGENERATION, 0);
                    case BAT -> desired.put(PotionEffectType.NIGHT_VISION, 9); // amplifier 9 = level X
                    case TURTLE -> desired.put(PotionEffectType.RESISTANCE, 0);
                    case WOLF -> desired.put(PotionEffectType.SPEED, 1);
                    case DOLPHIN -> {
                        if (player.isInWater()) {
                            desired.put(PotionEffectType.WATER_BREATHING, 0);
                            desired.put(PotionEffectType.DOLPHINS_GRACE, 0);
                        }
                    }
                    case GUARDIAN, ELDER_GUARDIAN -> {
                        if (player.isInWater()) desired.put(PotionEffectType.WATER_BREATHING, 0);
                    }
                    case GOAT -> desired.put(PotionEffectType.JUMP_BOOST, 0);
                    case SHULKER -> desired.put(PotionEffectType.RESISTANCE, 0);
                    case EVOKER -> desired.put(PotionEffectType.ABSORPTION, 0);
                    case IRON_GOLEM, ENDER_DRAGON -> desired.put(PotionEffectType.RESISTANCE, 0);
                    case GHAST, PHANTOM, ALLAY -> {
                        if (!player.isOnGround() && player.getVelocity().getY() < 0) desired.put(PotionEffectType.SLOW_FALLING, 0);
                    }
                    default -> { }
                }
            }

            Map<PotionEffectType, Integer> previous = appliedPassives.computeIfAbsent(player.getUniqueId(), ignored -> new HashMap<>());
            Map<PotionEffectType, Integer> appliedNow = new HashMap<>();
            for (Map.Entry<PotionEffectType, Integer> entry : desired.entrySet()) {
                PotionEffect current = player.getPotionEffect(entry.getKey());
                // Do not shorten or replace a stronger/longer effect supplied by a potion or another plugin.
                if (current == null || (current.getAmplifier() <= entry.getValue() && current.getDuration() <= 45)) {
                    player.addPotionEffect(new PotionEffect(entry.getKey(), 45, entry.getValue(), true, false, true), false);
                    PotionEffect after = player.getPotionEffect(entry.getKey());
                    if (after != null && after.getAmplifier() == entry.getValue() && after.getDuration() <= 45) {
                        appliedNow.put(entry.getKey(), entry.getValue());
                    }
                }
            }
            for (Map.Entry<PotionEffectType, Integer> old : new HashMap<>(previous).entrySet()) {
                if (!appliedNow.containsKey(old.getKey())) {
                    PotionEffect current = player.getPotionEffect(old.getKey());
                    if (current != null && current.getAmplifier() == old.getValue() && current.getDuration() <= 50) player.removePotionEffect(old.getKey());
                }
            }
            previous.clear();
            previous.putAll(appliedNow);

            if (worn != HeadType.SLIME && originalScales.containsKey(player.getUniqueId())
                    && plugin.getConfig().getBoolean("settings.reset-slime-scale-on-unequip", true)) {
                Double original = originalScales.remove(player.getUniqueId());
                if (original != null) setScale(player, original);
            }
        }
    }

    private boolean activate(Player player, HeadType head) {
        Location location = player.getLocation();
        Vector direction = location.getDirection().normalize();
        switch (head) {
            case ZOMBIE -> {
                effect(player, PotionEffectType.STRENGTH, 200, 1);
                effect(player, PotionEffectType.RESISTANCE, 100, 0);
            }
            case SKELETON -> {
                marksmanUntil.put(player.getUniqueId(), System.currentTimeMillis() + 10_000L);
                effect(player, PotionEffectType.SPEED, 120, 0);
                player.getWorld().spawnParticle(Particle.CRIT, location.add(0, 1.2, 0), 28, 0.45, 0.35, 0.45, 0.1);
            }
            case CREEPER -> {
                player.setVelocity(direction.multiply(0.65).setY(1.05));
                player.getWorld().spawnParticle(Particle.CLOUD, location, 35, 0.6, 0.25, 0.6, 0.12);
                player.getWorld().playSound(location, Sound.ENTITY_CREEPER_PRIMED, 0.8f, 1.7f);
            }
            case SPIDER -> {
                player.setVelocity(direction.multiply(0.75).setY(0.95));
                player.getWorld().spawnParticle(Particle.CLOUD, location, 18, 0.35, 0.35, 0.35, 0.05);
            }
            case CHICKEN -> {
                effect(player, PotionEffectType.SLOW_FALLING, 160, 0);
                player.setVelocity(direction.multiply(0.45).setY(0.85));
                player.getWorld().spawnParticle(Particle.CLOUD, location, 26, 0.45, 0.35, 0.45, 0.08);
            }
            case PIG -> {
                effect(player, PotionEffectType.SPEED, 160, 2);
                player.setVelocity(direction.multiply(0.55).setY(Math.max(0.25, player.getVelocity().getY())));
            }
            case COW -> {
                effect(player, PotionEffectType.REGENERATION, 160, 1);
                effect(player, PotionEffectType.ABSORPTION, 200, 0);
                player.getWorld().spawnParticle(Particle.HEART, location.add(0, 1, 0), 12, 0.5, 0.5, 0.5, 0.0);
            }
            case SHEEP -> effect(player, PotionEffectType.SLOW_FALLING, 120, 1);
            case BAT -> {
                effect(player, PotionEffectType.NIGHT_VISION, 240, 9);
                pulse(player, 5.0, 0, PotionEffectType.BLINDNESS, 50, 0);
            }
            case TURTLE -> {
                effect(player, PotionEffectType.RESISTANCE, 160, 1);
                effect(player, PotionEffectType.SLOWNESS, 100, 1);
                effect(player, PotionEffectType.ABSORPTION, 160, 1);
            }
            case ENDERMAN -> {
                Location destination = safeForwardLocation(player, 10.0);
                if (destination == null) return false;
                player.getWorld().spawnParticle(Particle.PORTAL, location.add(0, 1, 0), 28, 0.35, 0.6, 0.35, 0.3);
                player.teleport(destination);
                player.getWorld().spawnParticle(Particle.PORTAL, destination.add(0, 1, 0), 28, 0.35, 0.6, 0.35, 0.3);
                player.getWorld().playSound(destination, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.1f);
            }
            case BLAZE -> {
                effect(player, PotionEffectType.FIRE_RESISTANCE, 200, 0);
                SmallFireball fireball = player.launchProjectile(SmallFireball.class);
                fireball.setVelocity(direction.multiply(1.25));
                fireball.setIsIncendiary(false);
                fireball.setYield(0.0f);
            }
            case STRAY -> pulse(player, 6.0, 0, PotionEffectType.SLOWNESS, 100, 1);
            case WOLF -> {
                effect(player, PotionEffectType.SPEED, 160, 1);
                for (Entity entity : player.getNearbyEntities(7, 4, 7)) {
                    if (entity instanceof Player ally && !ally.equals(player)) effect(ally, PotionEffectType.SPEED, 120, 0);
                }
                player.getWorld().playSound(location, Sound.ENTITY_WOLF_AMBIENT, 0.9f, 1.0f);
            }
            case FOX -> {
                player.setVelocity(direction.multiply(-1.0).setY(0.45));
                effect(player, PotionEffectType.SPEED, 80, 1);
                player.getWorld().spawnParticle(Particle.CLOUD, location, 25, 0.35, 0.45, 0.35, 0.08);
            }
            case BEE -> {
                effect(player, PotionEffectType.ABSORPTION, 240, 2);
                effect(player, PotionEffectType.RESISTANCE, 120, 0);
                player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, location.add(0, 1, 0), 25, 0.5, 0.5, 0.5, 0.02);
            }
            case DOLPHIN -> {
                effect(player, PotionEffectType.WATER_BREATHING, 240, 0);
                effect(player, PotionEffectType.DOLPHINS_GRACE, 200, 1);
                player.setVelocity(direction.multiply(0.65).setY(0.35));
            }
            case GUARDIAN -> pushPulse(player, 7.0, 1.55);
            case GOAT -> {
                player.setVelocity(direction.multiply(1.35).setY(0.42));
                player.getWorld().spawnParticle(Particle.CLOUD, location, 30, 0.45, 0.35, 0.45, 0.06);
            }
            case HOGLIN -> {
                effect(player, PotionEffectType.RESISTANCE, 100, 1);
                effect(player, PotionEffectType.STRENGTH, 120, 0);
                player.setVelocity(direction.multiply(1.2).setY(0.35));
            }
            case WITHER_SKELETON -> {
                witherStrikeUntil.put(player.getUniqueId(), System.currentTimeMillis() + 8_000L);
                effect(player, PotionEffectType.STRENGTH, 100, 0);
                player.getWorld().spawnParticle(Particle.SMOKE, location.add(0, 1, 0), 25, 0.35, 0.55, 0.35, 0.03);
            }
            case GHAST -> {
                effect(player, PotionEffectType.INVISIBILITY, 70, 0);
                effect(player, PotionEffectType.SPEED, 100, 2);
                player.setVelocity(direction.multiply(0.85).setY(0.25));
            }
            case SHULKER -> pulse(player, 6.0, 0, PotionEffectType.LEVITATION, 50, 0);
            case EVOKER -> {
                effect(player, PotionEffectType.RESISTANCE, 160, 1);
                effect(player, PotionEffectType.ABSORPTION, 240, 2);
                player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, location.add(0, 1, 0), 35, 0.55, 0.65, 0.55, 0.05);
            }
            case PILLAGER -> {
                marksmanUntil.put(player.getUniqueId(), System.currentTimeMillis() + 12_000L);
                effect(player, PotionEffectType.SPEED, 100, 0);
                player.getWorld().spawnParticle(Particle.CRIT, location.add(0, 1.3, 0), 24, 0.3, 0.35, 0.3, 0.1);
            }
            case RAVAGER -> {
                player.setVelocity(direction.multiply(1.3).setY(0.45));
                pushPulse(player, 4.0, 0.9);
                player.getWorld().spawnParticle(Particle.CLOUD, location, 45, 0.6, 0.3, 0.6, 0.1);
            }
            case PHANTOM -> {
                effect(player, PotionEffectType.SLOW_FALLING, 220, 0);
                effect(player, PotionEffectType.SPEED, 180, 1);
                effect(player, PotionEffectType.JUMP_BOOST, 180, 1);
                player.setVelocity(direction.multiply(0.65).setY(0.65));
            }
            case SLIME -> { return false; }
            case ENDER_DRAGON -> shockwave(player, 9.0, 7.0, 2.1, false);
            case WITHER -> {
                pulse(player, 8.0, 0, PotionEffectType.WEAKNESS, 100, 0);
                pulse(player, 8.0, 0, PotionEffectType.SLOWNESS, 80, 0);
                player.getWorld().spawnParticle(Particle.SMOKE, location.add(0, 1, 0), 70, 1.2, 0.7, 1.2, 0.06);
                player.getWorld().playSound(location, Sound.ENTITY_WITHER_SPAWN, 0.6f, 1.5f);
            }
            case IRON_GOLEM -> {
                effect(player, PotionEffectType.RESISTANCE, 220, 1);
                effect(player, PotionEffectType.ABSORPTION, 240, 2);
                effect(player, PotionEffectType.SLOWNESS, 100, 0);
            }
            case WARDEN -> shockwave(player, 8.0, 6.0, 2.2, true);
            case ELDER_GUARDIAN -> {
                pulse(player, 8.0, 0, PotionEffectType.SLOWNESS, 140, 1);
                pulse(player, 8.0, 0, PotionEffectType.MINING_FATIGUE, 100, 0);
                player.getWorld().spawnParticle(Particle.BUBBLE, location.add(0, 1, 0), 50, 1, 0.5, 1, 0.04);
            }
            case PIGLIN_BRUTE -> {
                effect(player, PotionEffectType.STRENGTH, 180, 2);
                effect(player, PotionEffectType.RESISTANCE, 100, 0);
                effect(player, PotionEffectType.SLOWNESS, 100, 0);
                player.getWorld().playSound(location, Sound.ENTITY_PIGLIN_BRUTE_ANGRY, 1f, 0.9f);
            }
            case ALLAY -> {
                Location anchor = allayAnchors.get(player.getUniqueId());
                if (anchor == null || !isSafe(anchor)
                        || (plugin.getConfig().getBoolean("settings.allay-recall-requires-same-world", true)
                        && anchor.getWorld() != player.getWorld())) {
                    player.sendMessage(plugin.message("allay-no-point"));
                    return false;
                }
                Location safe = anchor.clone().add(0, 0.1, 0);
                if (!player.teleport(safe)) return false;
                player.getWorld().spawnParticle(Particle.END_ROD, safe.clone().add(0, 1, 0), 35, 0.4, 0.55, 0.4, 0.05);
                player.getWorld().playSound(safe, Sound.ENTITY_ALLAY_AMBIENT_WITH_ITEM, 1f, 1.2f);
                player.sendMessage(plugin.message("allay-recalled"));
            }
        }
        return true;
    }

    private void effect(Player player, PotionEffectType type, int ticks, int amplifier) {
        player.addPotionEffect(new PotionEffect(type, ticks, amplifier, true, false, true), true);
    }

    private void pulse(Player source, double radius, double unused, PotionEffectType effect, int ticks, int amplifier) {
        int max = plugin.getConfig().getInt("settings.max-area-targets", 24);
        int count = 0;
        for (Entity entity : source.getNearbyEntities(radius, radius, radius)) {
            if (count >= max) break;
            if (!isHostileTarget(source, entity)) continue;
            ((LivingEntity) entity).addPotionEffect(new PotionEffect(effect, ticks, amplifier, true, true, true), true);
            count++;
        }
    }

    private void pushPulse(Player source, double radius, double strength) {
        int max = plugin.getConfig().getInt("settings.max-area-targets", 24);
        int count = 0;
        for (Entity entity : source.getNearbyEntities(radius, radius, radius)) {
            if (count >= max) break;
            if (!isHostileTarget(source, entity)) continue;
            Vector away = entity.getLocation().toVector().subtract(source.getLocation().toVector());
            if (away.lengthSquared() < 0.01) away = new Vector(0, 0.2, 1);
            away.normalize().multiply(strength).setY(0.35);
            entity.setVelocity(away);
            count++;
        }
        source.getWorld().spawnParticle(Particle.CLOUD, source.getLocation(), 45, 0.9, 0.35, 0.9, 0.08);
    }

    private void shockwave(Player source, double radius, double damage, double knockback, boolean sonic) {
        int max = plugin.getConfig().getInt("settings.max-area-targets", 24);
        int count = 0;
        Location center = source.getLocation();
        for (Entity entity : source.getNearbyEntities(radius, radius, radius)) {
            if (count >= max) break;
            if (!isHostileTarget(source, entity)) continue;
            if (damage > 0 && entity instanceof LivingEntity living) living.damage(damage, source);
            Vector away = entity.getLocation().toVector().subtract(center.toVector());
            if (away.lengthSquared() < 0.01) away = new Vector(0, 0.2, 1);
            entity.setVelocity(away.normalize().multiply(knockback).setY(0.55));
            count++;
        }
        source.getWorld().spawnParticle(sonic ? Particle.SONIC_BOOM : Particle.EXPLOSION, center.add(0, 1, 0), sonic ? 1 : 2, 0, 0, 0, 0);
        source.getWorld().playSound(center, sonic ? Sound.ENTITY_WARDEN_SONIC_BOOM : Sound.ENTITY_GENERIC_EXPLODE, 1f, sonic ? 0.8f : 1.15f);
    }

    private boolean isHostileTarget(Player source, Entity entity) {
        if (entity.equals(source) || !(entity instanceof LivingEntity)) return false;
        if (entity instanceof Player other) return !other.equals(source);
        return entity instanceof Monster;
    }

    private Location safeForwardLocation(Player player, double maxDistance) {
        Location start = player.getLocation();
        Vector direction = start.getDirection().normalize();
        for (double distance = maxDistance; distance >= 1.0; distance -= 0.5) {
            Location candidate = start.clone().add(direction.clone().multiply(distance));
            candidate.setYaw(start.getYaw());
            candidate.setPitch(start.getPitch());
            Location feet = candidate.clone();
            Location head = candidate.clone().add(0, 1, 0);
            Location floor = candidate.clone().subtract(0, 1, 0);
            if (feet.getBlock().isPassable() && head.getBlock().isPassable() && floor.getBlock().getType().isSolid()) return candidate;
        }
        return null;
    }

    private boolean isSafe(Location location) {
        if (location.getWorld() == null) return false;
        return location.getBlock().isPassable() && location.clone().add(0, 1, 0).getBlock().isPassable()
                && location.clone().subtract(0, 1, 0).getBlock().getType().isSolid();
    }

    private boolean ready(Player player, HeadType head) {
        long now = System.currentTimeMillis();
        long expires = cooldowns.getOrDefault(player.getUniqueId(), Map.of()).getOrDefault(head.id(), 0L);
        if (expires > now) {
            long seconds = Math.max(1L, (expires - now + 999L) / 1000L);
            player.sendMessage(plugin.message("cooldown").replace("%seconds%", String.valueOf(seconds)));
            return false;
        }
        return true;
    }

    private void startCooldown(Player player, HeadType head) {
        cooldowns.computeIfAbsent(player.getUniqueId(), ignored -> new HashMap<>())
                .put(head.id(), System.currentTimeMillis() + plugin.cooldownMillis(head));
    }

    private void rememberOriginalScale(Player player, double current) {
        originalScales.putIfAbsent(player.getUniqueId(), current);
    }

    private double getScale(Player player) {
        try {
            AttributeInstance instance = player.getAttribute(Attribute.SCALE);
            return instance == null ? Double.NaN : instance.getBaseValue();
        } catch (Throwable ignored) {
            return Double.NaN;
        }
    }

    private boolean setScale(Player player, double value) {
        try {
            AttributeInstance instance = player.getAttribute(Attribute.SCALE);
            if (instance == null) return false;
            instance.setBaseValue(value);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public void restoreTrackedPlayerState() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Double scale = originalScales.get(player.getUniqueId());
            if (scale != null) setScale(player, scale);
        }
        for (Map.Entry<UUID, Map<PotionEffectType, Integer>> entry : appliedPassives.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player == null) continue;
            for (Map.Entry<PotionEffectType, Integer> effect : entry.getValue().entrySet()) {
                PotionEffect current = player.getPotionEffect(effect.getKey());
                if (current != null && current.getAmplifier() == effect.getValue() && current.getDuration() <= 50) player.removePotionEffect(effect.getKey());
            }
        }
    }
}
